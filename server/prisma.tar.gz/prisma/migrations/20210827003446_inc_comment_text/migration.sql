-- AlterTable
ALTER TABLE `comments` MODIFY `text` TEXT NOT NULL;
