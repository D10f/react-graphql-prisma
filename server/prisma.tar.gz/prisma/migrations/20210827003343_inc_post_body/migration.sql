-- AlterTable
ALTER TABLE `posts` MODIFY `body` TEXT NOT NULL;
